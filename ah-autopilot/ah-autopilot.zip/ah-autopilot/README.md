---
title: "AH Autopilot — AI-Operated Channel Build Plan"
researched: 2026-07-22
status: plan / not yet implemented
---

# AH Autopilot

A build plan for running Ancestral Healing with Claude + MCP connectors: analytics in,
scripts out, assets generated, videos assembled, publishing scheduled.

**Read `04-policy-and-risk.md` before spending money.** It contains a finding that
changes the shape of this project.

---

## Files

| File | What's in it |
|---|---|
| `index.html` | Visual overview — architecture, stack, costs |
| `01-connector-stack.md` | **Every connector you need**, with alternatives and setup order |
| `02-workflows-and-routines.md` | The 6 routines, what each does, cadence, prompts |
| `03-cost-model.md` | Three budget scenarios with real 2026 pricing |
| `04-policy-and-risk.md` | YouTube's AI rules and where this plan collides with them |
| `05-implementation-roadmap.md` | 6-week build order |

---

## The honest reframe

You asked for a channel that is **self-running by AI, keeps the branding, and goes viral**.

Two of those three are achievable now. The third needs restating, and here's why.

### Finding 1 — "fully self-running" is the thing YouTube penalises

<cite index="6-1">YouTube's inauthentic content policy makes repetitive, mass-produced content ineligible for monetization in the YouTube Partner Program, and it is the rule most directly aimed at low-effort, template-driven and unoriginal AI-generated videos.</cite> <cite index="8-1">Enforcement now evaluates channels as a whole — upload frequency, format similarity, lack of commentary and minimal editing all stack up as risk signals.</cite>

<cite index="2-1">Failure to disclose synthetic content triggers a three-strike sequence: warning, 90-day monetization suspension, then permanent removal from the Partner Program.</cite>

This is not an AI ban. <cite index="1-1">YouTube maintains a tool-agnostic stance — using generative AI does not disqualify content from the Partner Program if it meets authenticity standards, and high-quality AI-assisted content that enhances creativity is encouraged.</cite> <cite index="3-1">A channel using AI tools inside a genuinely original production, with a real script and real editorial decisions, remains eligible.</cite>

**The line is human editorial judgment, not tool usage.** An AI-assisted pipeline with you making the calls is fine. A pipeline that publishes without you is the exact pattern being enforced against.

### Finding 2 — your own data says the same thing

From the analytics we already pulled, your top videos are:

1. "CARNIVORE DIET: 5 Things That No One Talks About" — 71,000
2. "I Eat Burgers with EVERY Meal" — 56,000
3. "5 REASONS WHY CARNIVORE MAY NOT BE WORKING" — 29,000

**Lived personal experience and honest admission of difficulty.** That is precisely the
category AI cannot generate, because it isn't a format — it's you having actually done
the thing for three years.

And the sharpest number in the whole dataset:

| | Views |
|---|---|
| "9 Ways To Connect With Your Ancestors Through Food" | 1,100 |
| "9 WAYS TO ADD MORE FAT ON AN ANIMAL BASED DIET" | 15,000 |

Same structure. **13× apart.** The difference is lived specificity.

So the automation and the virality pull in opposite directions on this particular
channel. Automating the *production* is high-leverage. Automating the *voice* would
remove the thing that actually works.

### The version that works

> **Automate everything except the judgment and the face.**

| Automate fully | Keep human |
|---|---|
| Analytics pulls and reporting | Which topic to make |
| Competitor and trend monitoring | The personal story and opinion |
| Research briefs from the AH Brain archive | Final script approval |
| First-draft scripts | On-camera delivery (or your cloned voice) |
| Thumbnails and title variants | Fact-check on Tier-3 claims |
| B-roll generation | Publish button |
| Metadata, chapters, descriptions, tags | |
| Scheduling and comment triage | |

That's realistically **80% of the labour** with none of the policy exposure — and it
protects the exact quality your best videos are built on.

**Throughput this buys you:** roughly 2–3× current output at the same personal time
cost. Not infinite, but the constraint moves from "how fast can I edit" to "how fast
can I decide and record."

---

## Architecture in one picture

```
                    ┌──────────────────────────────┐
                    │      AH BRAIN (Project)      │
                    │  29 research docs · voice ·  │
                    │  editorial guidelines        │
                    └──────────────┬───────────────┘
                                   │
   ┌───────────────┐        ┌──────▼───────┐        ┌──────────────────┐
   │  ANALYTICS    │───────▶│    CLAUDE    │◀───────│   GENERATION     │
   │  YouTube API  │        │  + Routines  │        │  images · voice  │
   │  TubeLab      │        │  + Skills    │        │  video · avatar  │
   └───────────────┘        └──────┬───────┘        └──────────────────┘
                                   │
                          ┌────────▼─────────┐
                          │  ⚠ HUMAN GATE    │   ← non-negotiable
                          │  approve · record │
                          │  fact-check       │
                          └────────┬─────────┘
                                   │
                          ┌────────▼─────────┐
                          │  PUBLISH         │
                          │  + AI disclosure │
                          └──────────────────┘
```

---

## Quick answer: what connectors do I need?

Minimum viable set — full detail and alternatives in `01-connector-stack.md`:

| # | Purpose | Pick |
|---|---|---|
| 1 | YouTube read + analytics | Composio (Rube) YouTube, or Windsor MCP |
| 2 | YouTube write / upload | Composio YouTube with OAuth write scope |
| 3 | Competitive intel | **TubeLab** — already connected |
| 4 | Image / thumbnail generation | CreativeClaw or Nano Banana MCP |
| 5 | Voice | ElevenLabs MCP (official) |
| 6 | Video / avatar | HeyGen MCP (official) |
| 7 | Archive + versioning | GitHub — already have the repo |
| 8 | Asset storage | Google Drive |

Plus **custom skills** you write yourself (not connectors) for scripting, thumbnails and
metadata — covered in `02-workflows-and-routines.md`.

---

## Budget headline

| Scenario | Output / month | Monthly cost |
|---|---|---|
| Lean (validate first) | 4 long + 8 shorts | **~$155** |
| Standard (recommended) | 8 long + 12 shorts | **~$285** |
| Aggressive | 12 long + 20 shorts | **~$520** |

Full breakdown, including what's fixed vs variable, in `03-cost-model.md`.

---

## Sources and freshness

Researched 22 July 2026 via web search. Pricing in this plan moves fast — the video-gen
market especially. Re-verify before committing spend. Every figure is sourced in
`03-cost-model.md`.
